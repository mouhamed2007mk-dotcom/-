# Mauritania Cars

منصة Full-Stack لتأجير السيارات في موريتانيا، مبنية بـ Next.js + TypeScript + PostgreSQL + Prisma.

## المتطلبات
- Node.js 20+
- PostgreSQL 15+

## التشغيل
1. انسخ `.env.example` إلى `.env`.
2. ضع `DATABASE_URL` و`AUTH_SECRET` وبيانات Admin.
3. ثبّت الحزم: `npm install`
4. أنشئ قاعدة البيانات: `npm run db:migrate`
5. Seed: `npm run db:seed`
6. شغّل: `npm run dev`

## أهم المتغيرات
`DATABASE_URL`, `AUTH_SECRET`, `ADMIN_PHONE`, `ADMIN_PASSWORD`, وإعدادات WhatsApp الخاصة بالتواصل عبر لوحة الإدارة.

تسجيل الدخول وإنشاء الحساب يعتمدان على رقم WhatsApp الموريتاني بصيغة +222، بدون أي رمز تحقق أو OTP. WhatsApp يستخدم للتواصل مع العملاء والدعم فقط. إعادة ضبط كلمة المرور تتم عبر إدارة الموقع لتجنب آلية OTP. رقم الإدارة الافتراضي هو `+22248907084`.

## المسارات
- `/` الموقع
- `/cars` الكتالوج
- `/cars/[id]` تفاصيل السيارة والحجز
- `/login`, `/register`
- `/account`
- `/admin` ولوحات الإدارة
- `/api/auth/*`, `/api/cars`, `/api/bookings`, `/api/reviews`, `/api/contact`

## الأمان
- كلمات المرور bcrypt
- جلسة JWT داخل HTTP-only cookie
- Zod validation
- RBAC
- حساب السعر من قاعدة البيانات على الخادم
- منع تعارض الحجوزات داخل transaction مع Serializable isolation
- عدم تخزين الأسرار في Git

## الصور
يمكن لاحقًا ربط Cloudinary/S3 عبر طبقة storage؛ seed يستخدم صورًا عامة للتطوير فقط.

## الإنتاج
قبل النشر غيّر `AUTH_SECRET`، كلمة مرور Admin، SMTP، وقاعدة البيانات. أضف reverse proxy/TLS وراقب logs وقاعدة البيانات.

## ملاحظة عن الاختبار في بيئة البناء الحالية
تمت مراجعة البنية والكود والاعتماديات، لكن بيئة التنفيذ الحالية لم تسمح بإكمال `npm install` ضمن المهلة، لذلك لا أدّعي أن تكامل PostgreSQL/Prisma تم تشغيله هنا. بعد وضع `.env` وتشغيل PostgreSQL نفّذ `npm install && npm run db:migrate && npm run db:seed && npm run typecheck && npm test && npm run build`.
