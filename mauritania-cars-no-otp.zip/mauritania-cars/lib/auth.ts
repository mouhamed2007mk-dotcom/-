import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { prisma } from "./prisma";
const secret = new TextEncoder().encode(process.env.AUTH_SECRET || "dev-secret-change-me");
const COOKIE="mc_session";
export async function hashPassword(password:string){return bcrypt.hash(password,12)}
export async function verifyPassword(password:string,hash:string){return bcrypt.compare(password,hash)}
export async function createSession(userId:string){
 const token=await new SignJWT({sub:userId}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("7d").sign(secret);
 (await cookies()).set(COOKIE,token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:60*60*24*7});
}
export async function clearSession(){(await cookies()).delete(COOKIE)}
export async function getSessionUser(){
 const token=(await cookies()).get(COOKIE)?.value; if(!token)return null;
 try{const {payload}=await jwtVerify(token,secret); if(!payload.sub)return null; return prisma.user.findUnique({where:{id:String(payload.sub)}})}catch{return null}
}
export async function requireUser(){const u=await getSessionUser(); if(!u) throw new Error("UNAUTHORIZED"); return u}
export function canManage(role:string, area:string){
 if(role==="SUPER_ADMIN")return true;
 if(role==="ADMIN")return ["cars","bookings","users","reviews","coupons","messages","analytics","settings"].includes(area);
 if(role==="MANAGER")return ["cars","bookings"].includes(area);
 return false;
}
