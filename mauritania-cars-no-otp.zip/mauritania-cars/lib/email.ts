import nodemailer from "nodemailer";
export async function sendEmail(to:string,subject:string,html:string){
 const host=process.env.SMTP_HOST; if(!host) return false;
 const port=Number(process.env.SMTP_PORT||587);
 const t=nodemailer.createTransport({host,port,secure:port===465,auth:{user:process.env.SMTP_USER,password:process.env.SMTP_PASSWORD}});
 await t.sendMail({from:process.env.SMTP_FROM||"Mauritania Cars <no-reply@example.com>",to,subject,html}); return true;
}
