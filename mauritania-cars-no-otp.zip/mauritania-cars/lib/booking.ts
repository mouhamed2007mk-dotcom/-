import { prisma } from "./prisma";
import { Prisma } from "@prisma/client";
export const BLOCKING=["PENDING","CONFIRMED"] as const;
export function calcDays(pickup:Date,ret:Date){const ms=ret.getTime()-pickup.getTime(); return Math.max(1,Math.ceil(ms/86400000));}
export async function ensureAvailable(tx:Prisma.TransactionClient,carId:string,pickup:Date,ret:Date){
 const conflict=await tx.booking.findFirst({where:{carId,status:{in:["PENDING","CONFIRMED"]},pickupAt:{lt:ret},returnAt:{gt:pickup}}});
 if(conflict) throw new Error("CAR_UNAVAILABLE");
}
export async function calculatePrice(tx:Prisma.TransactionClient,input:{carId:string,pickup:Date,ret:Date,couponCode?:string,withDriver?:boolean}){
 const car=await tx.car.findUnique({where:{id:input.carId}}); if(!car)throw new Error("CAR_NOT_FOUND");
 const days=calcDays(input.pickup,input.ret); let daily=Number(car.dailyPrice); let subtotal=daily*days;
 if(days>=30 && car.monthlyPrice) subtotal=Number(car.monthlyPrice)*Math.ceil(days/30);
 else if(days>=7 && car.weeklyPrice) subtotal=Number(car.weeklyPrice)*Math.ceil(days/7);
 if(input.withDriver && car.driverPrice) subtotal += Number(car.driverPrice)*days;
 let discount=0; let coupon=null;
 if(input.couponCode){coupon=await tx.coupon.findUnique({where:{code:input.couponCode.toUpperCase()}}); const now=new Date(); if(!coupon||!coupon.active||now<coupon.startAt||now>coupon.endAt||(coupon.maxUses!==null&&coupon.uses>=coupon.maxUses)|| (coupon.minBookingAmount&&subtotal<Number(coupon.minBookingAmount))) throw new Error("INVALID_COUPON"); discount=coupon.type==="PERCENTAGE"?subtotal*(Number(coupon.value)/100):Number(coupon.value); discount=Math.min(discount,subtotal);}
 const settings=await tx.siteSettings.findUnique({where:{id:"singleton"}}); const serviceFee=Number(settings?.serviceFee||0); const taxRate=Number(settings?.tax||0); const taxable=Math.max(0,subtotal-discount); const tax=taxable*(taxRate/100); const total=taxable+serviceFee+tax;
 return {car,days,dailyRate:daily,subtotal,discount,serviceFee:serviceFee+tax,total};
}
export async function createBooking(input:{userId:string;carId:string;pickupLocationId:string;returnLocationId:string;pickupAt:Date;returnAt:Date;withDriver:boolean;notes?:string;couponCode?:string}){
 if(input.returnAt<=input.pickupAt)throw new Error("INVALID_DATES");
 for(let attempt=0;attempt<2;attempt++){
  try{return await prisma.$transaction(async tx=>{await ensureAvailable(tx,input.carId,input.pickupAt,input.returnAt); const c=await calculatePrice(tx,input); const count=await tx.booking.count(); const year=new Date().getFullYear(); const reference=`MR-CAR-${year}-${String(count+1).padStart(6,"0")}`; const b=await tx.booking.create({data:{reference,userId:input.userId,carId:input.carId,pickupLocationId:input.pickupLocationId,returnLocationId:input.returnLocationId,pickupAt:input.pickupAt,returnAt:input.returnAt,withDriver:input.withDriver,notes:input.notes,days:c.days,dailyRate:c.dailyRate,subtotal:c.subtotal,discount:c.discount,serviceFee:c.serviceFee,total:c.total,couponCode:input.couponCode?.toUpperCase()}}); await tx.bookingStatusHistory.create({data:{bookingId:b.id,toStatus:"PENDING",changedById:input.userId}}); if(input.couponCode)await tx.coupon.update({where:{code:input.couponCode.toUpperCase()},data:{uses:{increment:1}}}); return b},{isolationLevel:Prisma.TransactionIsolationLevel.Serializable});}catch(e){if(attempt===1)throw e;}
 }
 throw new Error("BOOKING_FAILED");
}
