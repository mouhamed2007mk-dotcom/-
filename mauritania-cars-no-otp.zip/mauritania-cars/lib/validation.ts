import { z } from "zod";

export const phoneSchema = z.string().regex(/^\+222\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{2}$/, "Invalid Mauritanian phone");
export function normalizeMauritaniaPhone(phone: string) {
  const digits = phone.replace(/\D/g, "");
  return digits.startsWith("222") ? `+${digits}` : `+222${digits}`;
}
export const registerSchema = z.object({ name: z.string().min(2).max(80), phone: phoneSchema, password: z.string().min(8).max(100), email: z.string().email().optional().or(z.literal("")) });
export const loginSchema = z.object({ phone: phoneSchema, password: z.string().min(1) });
export const bookingSchema = z.object({carId:z.string(),pickupLocationId:z.string(),returnLocationId:z.string(),pickupAt:z.coerce.date(),returnAt:z.coerce.date(),withDriver:z.boolean().default(false),notes:z.string().max(1000).optional(),couponCode:z.string().max(50).optional()});
export const carSchema = z.object({brand:z.string().min(1),model:z.string().min(1),year:z.number().int().min(1950).max(2100),seats:z.number().int().min(1).max(50),doors:z.number().int().min(2).max(8),fuel:z.enum(["PETROL","DIESEL","HYBRID","ELECTRIC"]),transmission:z.enum(["AUTOMATIC","MANUAL"]),dailyPrice:z.number().nonnegative(),weeklyPrice:z.number().nonnegative().optional(),monthlyPrice:z.number().nonnegative().optional(),driverPrice:z.number().nonnegative().optional(),locationId:z.string(),description:z.string().min(10),features:z.array(z.string()).default([]),slug:z.string().min(2)});
