export function formatMauritaniaPhone(phone: string) {
  const digits = phone.replace(/\D/g, "");
  return digits.startsWith("222") ? `+${digits}` : `+222${digits}`;
}

export function whatsappLink(phone: string, message = "") {
  const digits = phone.replace(/\D/g, "");
  return `https://wa.me/${digits}${message ? `?text=${encodeURIComponent(message)}` : ""}`;
}
