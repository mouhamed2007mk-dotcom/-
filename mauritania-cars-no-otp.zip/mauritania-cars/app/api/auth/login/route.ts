import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyPassword, createSession } from "@/lib/auth";
import { loginSchema, normalizeMauritaniaPhone } from "@/lib/validation";
import { formatMauritaniaPhone } from "@/lib/whatsapp";

export async function POST(req: Request) {
  try {
    const body = loginSchema.parse(await req.json());
    const phone = formatMauritaniaPhone(normalizeMauritaniaPhone(body.phone));
    const user = await prisma.user.findUnique({ where: { phone } });
    if (!user || user.status === "DISABLED" || !(await verifyPassword(body.password, user.passwordHash))) return NextResponse.json({ error: "رقم الهاتف أو كلمة المرور غير صحيحة" }, { status: 401 });
    await createSession(user.id);
    return NextResponse.json({ user: { id: user.id, name: user.name, role: user.role, phone: user.phone } });
  } catch { return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 }); }
}
