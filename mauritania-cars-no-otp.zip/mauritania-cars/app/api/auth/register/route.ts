import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword, createSession } from "@/lib/auth";
import { normalizeMauritaniaPhone, registerSchema } from "@/lib/validation";
import { formatMauritaniaPhone } from "@/lib/whatsapp";

export async function POST(req: Request) {
  try {
    const body = registerSchema.parse(await req.json());
    const phone = formatMauritaniaPhone(normalizeMauritaniaPhone(body.phone));
    if (await prisma.user.findUnique({ where: { phone } })) return NextResponse.json({ error: "رقم واتساب مستخدم بالفعل" }, { status: 409 });
    const email = body.email?.trim() || null;
    if (email && await prisma.user.findUnique({ where: { email } })) return NextResponse.json({ error: "البريد مستخدم بالفعل" }, { status: 409 });
    const user = await prisma.user.create({ data: { name: body.name, phone, email, passwordHash: await hashPassword(body.password) } });
    await createSession(user.id);
    return NextResponse.json({ user: { id: user.id, name: user.name, role: user.role, phone: user.phone } });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "بيانات غير صالحة" }, { status: 400 }); }
}
